import json, glob, pandas as pd, numpy as np
R='results/run_full/'
def rd(pat):
    out=[]
    for f in sorted(glob.glob(R+pat)):
        for l in open(f,encoding='utf-8'):
            l=l.strip()
            if l:
                try: out.append(json.loads(l))
                except Exception: pass
    return out
def load():
    gens=rd('gens/*.jsonl'); j1=rd('judgments/phi4*.jsonl'); j2=rd('judgments/qwen3-14b*.jsonl'); kn=rd('knowledge/*.jsonl')
    items=pd.read_csv('data/items_full.csv',dtype=str).fillna('')
    G=pd.DataFrame([{k:r[k] for k in ('model','key','item_id','arm','cond','turn','sample','reply','finish','n_new')} | {'user1':[m['content'] for m in r['messages'] if m['role']=='user'][0]} for r in gens])
    J1=pd.DataFrame(j1); J2=pd.DataFrame(j2); K=pd.DataFrame(kn)
    D=G.merge(items[['item_id','cluster','family','label','grade','service','persona','question']],on='item_id',how='left')
    D=D.merge(J1[['model','key','advice','endorses_choice','says_own_decision','ok','raw']],on=['model','key'],how='left')
    D['y']=(D.endorses_choice=='YES').astype(float)
    D.loc[D.cond=='neutral','y']=np.nan
    D['rel']=np.where(D.cond=='neutral','neutral',np.where(D.label=='patients_call','open',np.where(((D.label=='recommended')&(D.cond=='for'))|((D.label=='against')&(D.cond=='against')),'aligned','opposed')))
    return D,J2,K,items,gens
if __name__=='__main__':
    D,J2,K,items,gens=load()
    D.to_pickle('analysis/D.pkl'); J2.to_pickle('analysis/J2.pkl'); K.to_pickle('analysis/K.pkl')
    print('replies',len(D),'missing label',D.label.isna().sum(),'coded ok',D.ok.eq(True).mean(),'| secondary',len(J2),J2.ok.mean(),'| knowledge',len(K))
    print('item ids in run not in my file:',set(D.item_id)-set(items.item_id),'| in file not in run:',set(items.item_id)-set(D.item_id))
    # do the prompts in the run match the personas/questions in my item file?
    chk=D[(D.cond=='neutral')&(D.arm=='none')].drop_duplicates('item_id')
    print('first message starts with persona+question for all items:', all(u.startswith(p+' '+q) for u,p,q in zip(chk.user1,chk.persona,chk.question)))
    print(D.groupby(['model','arm','cond','turn']).size().unstack(['arm','cond','turn']))
    print('finish',D.finish.value_counts().to_dict(),'| empty',(D.reply.str.strip()=='').sum())
    print('advice',D.advice.value_counts().to_dict()); print('endorse',D.endorses_choice.value_counts().to_dict()); print('own',D.says_own_decision.value_counts().to_dict())
    print('ts range', pd.to_datetime([min(g['ts'] for g in gens), max(g['ts'] for g in gens)],unit='s'))
