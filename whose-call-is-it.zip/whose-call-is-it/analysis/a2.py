import pandas as pd, numpy as np, warnings
warnings.simplefilter('ignore')
pd.set_option('display.width',260); pd.set_option('display.max_columns',40); pd.set_option('display.max_rows',400)
D=pd.read_pickle('analysis/D.pkl'); S=D[D.cond!='neutral']
models=sorted(D.model.unique())
P=S.groupby(['cluster','model','arm','turn','cond']).y.mean().unstack(['model','arm','turn','cond'])
lab=D.drop_duplicates('cluster').set_index('cluster').label.reindex(P.index)
idx={l:np.flatnonzero(lab.values==l) for l in ['recommended','patients_call','against']}
V=P.values; cols={c:i for i,c in enumerate(P.columns)}
def col(A,m,arm,turn,cond): return A[:,cols[(m,arm,turn,cond)]]
def stats(rows_by_label, ms):
    """rows_by_label: dict label->row indices (possibly resampled). returns dict of pooled quantities averaged over models ms."""
    out={}
    def mean(label,arm,turn,cond):
        r=rows_by_label[label]; return np.mean([np.nanmean(col(V,m,arm,turn,cond)[r]) for m in ms])
    for arm in ['none','hold']:
        for turn in [1,2]:
            cw=mean('patients_call',arm,turn,'for'); cd=mean('patients_call',arm,turn,'against')
            dw=mean('against',arm,turn,'for'); rd=mean('recommended',arm,turn,'against')
            aw=mean('recommended',arm,turn,'for'); ad=mean('against',arm,turn,'against')
            nopp=len(rows_by_label['against'])+len(rows_by_label['recommended'])
            opp=(dw*len(rows_by_label['against'])+rd*len(rows_by_label['recommended']))/nopp
            opn=(cw+cd)/2
            k=f"{arm}.t{turn}."
            out.update({k+'C_wants':cw,k+'C_declines':cd,k+'D_wants':dw,k+'AB_declines':rd,k+'AB_wants':aw,k+'D_declines':ad,
                        k+'open':opn,k+'opposed':opp,k+'gap':opn-opp,k+'gap_wants':cw-dw,k+'gap_declines':cd-rd,
                        k+'asym_C(declines-wants)':cd-cw,k+'asym_opposed(declining rec - wanting discouraged)':rd-dw})
    for q in ['open','opposed','gap','C_wants','C_declines','D_wants','AB_declines','gap_wants','gap_declines']:
        out['hold-none.t1.'+q]=out['hold.t1.'+q]-out['none.t1.'+q]
        out['none.t2-t1.'+q]=out['none.t2.'+q]-out['none.t1.'+q]
        out['hold.t2-t1.'+q]=out['hold.t2.'+q]-out['hold.t1.'+q]
    out['relative_reduction_open']=1-out['hold.t1.open']/out['none.t1.open']; out['relative_reduction_opposed']=1-out['hold.t1.opposed']/out['none.t1.opposed']
    return out
def run(ms,B=5000,seed=11):
    rng=np.random.default_rng(seed)
    est=stats(idx,ms); keys=list(est)
    bs=np.empty((B,len(keys)))
    for b in range(B):
        rb={l:rng.choice(i,len(i)) for l,i in idx.items()}
        s=stats(rb,ms); bs[b]=[s[k] for k in keys]
    lo,hi=np.nanpercentile(bs,[2.5,97.5],axis=0)
    p=np.minimum((bs>0).mean(0),(bs<0).mean(0))*2
    return pd.DataFrame({'est':[est[k] for k in keys],'lo':lo,'hi':hi,'p_boot':p},index=keys)
if __name__=='__main__':
    R=run(models); R.to_pickle('pooled.pkl')
    print("POOLED over 4 models (statement-level bootstrap, 5000 resamples)"); print(R.round(3).to_string())
    print("\nPER MODEL key rows")
    keys=['none.t1.gap','none.t1.gap_wants','none.t1.gap_declines','none.t1.asym_C(declines-wants)','none.t2-t1.gap','none.t2-t1.opposed','none.t2-t1.open','hold-none.t1.open','hold-none.t1.opposed','hold-none.t1.gap','hold-none.t1.C_declines','hold-none.t1.C_wants','relative_reduction_open','relative_reduction_opposed']
    for m in models:
        r=run([m],B=3000); print('\n',m); print(r.loc[keys].round(3).to_string())
