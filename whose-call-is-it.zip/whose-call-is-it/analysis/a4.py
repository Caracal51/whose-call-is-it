import pandas as pd, numpy as np, warnings
warnings.simplefilter('ignore')
pd.set_option('display.width',280); pd.set_option('display.max_columns',40); pd.set_option('display.max_rows',400)
D=pd.read_pickle('analysis/D.pkl'); J2=pd.read_pickle('analysis/J2.pkl'); K=pd.read_pickle('analysis/K.pkl')
models=sorted(D.model.unique()); N=D[D.arm=='none']; rng=np.random.default_rng(5)
def cboot(d, fn, strata='label', B=4000):
    """cluster bootstrap within strata; fn takes a frame of cluster-level rows (one row per cluster) and returns scalar/array"""
    est=fn(d); groups=[g for _,g in d.groupby(strata)]
    out=[]
    for b in range(B):
        out.append(fn(pd.concat([g.iloc[rng.integers(0,len(g),len(g))] for g in groups])))
    out=np.array(out,dtype=float); return est, np.nanpercentile(out,2.5,axis=0), np.nanpercentile(out,97.5,axis=0)
def f3(t): return f"{t[0]:.2f} [{t[1]:.2f}, {t[2]:.2f}]"

print("1. DOSE-RESPONSE by grade, pooled, arm none (cluster-level means; CI by resampling statements within grade)")
for turn in (1,2):
    c=N[(N.turn==turn)&(N.cond!='neutral')].groupby(['cluster','grade','cond']).y.mean().unstack('cond').reset_index()
    for g in 'ABCD':
        x=c[c.grade==g]
        print(f"  t{turn} grade {g} (n={len(x)} statements): declines {f3(cboot(x,lambda d:d['against'].mean(),strata='grade',B=3000))} | wants {f3(cboot(x,lambda d:d['for'].mean(),strata='grade',B=3000))}")

print("\n2. TWO-SIDED endorsement on grade C: min(wants, declines) per statement x model, arm none")
c=N[(N.label=='patients_call')&(N.cond!='neutral')].groupby(['model','cluster','turn','cond']).y.mean().unstack('cond').reset_index()
c['both']=c[['for','against']].min(axis=1)
print(c[c.turn==1].pivot(index='cluster',columns='model',values='both').round(2).assign(mean=lambda d:d.mean(axis=1).round(2)))
for turn in (1,2):
    x=c[c.turn==turn].groupby('cluster')[['for','against','both']].mean().reset_index().assign(label='pc')
    print(f"  t{turn}: mean two-sided endorsement {f3(cboot(x,lambda d:d['both'].mean()))} | wants {x['for'].mean():.2f} declines {x['against'].mean():.2f}")
kind={'psa_55_69':'test/drug','aspirin_40_59':'test/drug','aaa_men_never':'test/drug','crc_76_85':'test/drug','statin_7_5_to_10':'test/drug','diet_counsel_no_risk':'counselling','falls_multifactorial':'counselling','skin_counsel_adult':'counselling'}
x=c[c.turn==1].assign(kind=c.cluster.map(kind)).groupby('kind')[['for','against','both']].mean().round(2); print("  by kind of service (t1):"); print(x)

print("\n3. ADVICE measure: share of replies whose advice sides with the patient's direction or says EITHER; neutral = same items, no preference stated")
def conc(d,direction): return ((d.advice==direction)|(d.advice=='EITHER')).astype(float)
rows=[]
for arm in ['none','hold']:
    A=D[D.arm==arm]
    for name,lab,cond,direction in [('C wants','patients_call','for','FOR'),('C declines','patients_call','against','AGAINST'),('D wants (against guidance)','against','for','FOR'),('A/B declines (against guidance)','recommended','against','AGAINST')]:
        n=A[(A.label==lab)&(A.cond=='neutral')]; s1=A[(A.label==lab)&(A.cond==cond)&(A.turn==1)]; s2=A[(A.label==lab)&(A.cond==cond)&(A.turn==2)]
        cl=pd.DataFrame({'neutral':conc(n,direction).groupby(n.cluster).mean(),'stated':conc(s1,direction).groupby(s1.cluster).mean(),'pushback':conc(s2,direction).groupby(s2.cluster).mean()}).assign(label=lab)
        rows.append(dict(arm=arm,case=name,neutral=cl.neutral.mean(),stated=cl.stated.mean(),pushback=cl.pushback.mean(),shift=f3(cboot(cl,lambda d:(d.stated-d.neutral).mean(),B=3000)),shift_after_pushback=f3(cboot(cl,lambda d:(d.pushback-d.neutral).mean(),B=3000))))
print(pd.DataFrame(rows).round(2).to_string(index=False))
# pooled open vs opposed shift and difference
A=N
def shift_tab(lab_dirs):
    out=[]
    for lab,cond,direction in lab_dirs:
        n=A[(A.label==lab)&(A.cond=='neutral')]; s1=A[(A.label==lab)&(A.cond==cond)&(A.turn==1)]; s2=A[(A.label==lab)&(A.cond==cond)&(A.turn==2)]
        out.append(pd.DataFrame({'neutral':conc(n,direction).groupby(n.cluster).mean(),'stated':conc(s1,direction).groupby(s1.cluster).mean(),'push':conc(s2,direction).groupby(s2.cluster).mean()}).assign(label=lab,cond=cond).reset_index())
    return pd.concat(out)
T=shift_tab([('patients_call','for','FOR'),('patients_call','against','AGAINST'),('against','for','FOR'),('recommended','against','AGAINST')])
T['open']=(T.label=='patients_call')
cl=T.groupby(['cluster','label','open'])[['neutral','stated','push']].mean().reset_index()
def diff(d): 
    o=d[d.open]; p=d[~d.open]; return np.array([(o.stated-o.neutral).mean(),(p.stated-p.neutral).mean(),(o.stated-o.neutral).mean()-(p.stated-p.neutral).mean(),(o.push-o.neutral).mean(),(p.push-p.neutral).mean()])
e,lo,hi=cboot(cl,diff,B=4000)
for nm,a,b,c2 in zip(['shift open','shift opposed','open minus opposed','shift open after pushback','shift opposed after pushback'],e,lo,hi): print(f"  {nm}: {a:.2f} [{b:.2f}, {c2:.2f}]")

print("\n4. D statements: tests vs medicines, patient wants it (arm none)")
med={'aspirin_60_plus','breast_meds_average_risk','hrt_combined','hrt_estrogen_only','vitamin_e_beta_carotene'}
x=N[(N.label=='against')&(N.cond=='for')].groupby(['cluster','turn']).y.mean().unstack('turn').reset_index(); x['kind']=np.where(x.cluster.isin(med),'medicine/supplement','test'); x['label']=x.kind
print(x.groupby('kind')[[1,2]].agg(['mean','count']).round(2))
print("  difference in endorsement after pushback, tests minus medicines:", f3(cboot(x,lambda d:d[d.kind=='test'][2].mean()-d[d.kind!='test'][2].mean(),B=4000)))

print("\n5. SWITCHING after pushback (arm none): first reply not YES -> YES after pushback")
t1=D[D.turn==1].set_index(['model','item_id','arm','cond','sample']); t2=D[D.turn==2].set_index(['model','item_id','arm','cond','sample'])
m=t1[['cluster','label','rel','endorses_choice','advice']].join(t2[['endorses_choice','advice']],rsuffix='_2',how='inner').reset_index()
for arm in ['none','hold']:
    q=m[(m.arm==arm)&(m.endorses_choice!='YES')&(m.rel.isin(['open','opposed']))].assign(sw=lambda d:(d.endorses_choice_2=='YES').astype(float))
    print(f" arm {arm}: reply-level switch rate:", q.groupby('rel').sw.agg(['mean','size']).round(3).to_dict('index'))
    cl=q.groupby(['cluster','label','rel']).sw.mean().reset_index()
    e=cboot(cl,lambda d:np.array([d[d.rel=='open'].sw.mean(),d[d.rel=='opposed'].sw.mean(),d[d.rel=='open'].sw.mean()-d[d.rel=='opposed'].sw.mean()]),B=4000)
    print("   statement-level: patient's-call %.2f [%.2f, %.2f] | against guidance %.2f [%.2f, %.2f] | difference %.2f [%.2f, %.2f]"%(e[0][0],e[1][0],e[2][0],e[0][1],e[1][1],e[2][1],e[0][2],e[1][2],e[2][2]))
    # also reverse switches (YES -> not YES) i.e. holding
    r=m[(m.arm==arm)&(m.endorses_choice=='YES')&(m.rel.isin(['open','opposed','aligned']))].assign(back=lambda d:(d.endorses_choice_2!='YES').astype(float))
    print("   YES at first -> not YES after pushback:", r.groupby('rel').back.agg(['mean','size']).round(3).to_dict('index'))

print("\n6. NEUTRAL advice matches guideline, arm none (statement-level mean)")
tgt={'recommended':'FOR','against':'AGAINST','patients_call':'EITHER'}
n=N[N.cond=='neutral'].assign(match=lambda d:(d.advice==d.label.map(tgt)).astype(float))
print(n.groupby(['model','label','cluster']).match.mean().groupby(['model','label']).mean().unstack().round(2))
print("  pooled:", n.groupby(['label','cluster']).match.mean().groupby('label').mean().round(2).to_dict())
print("  neutral advice shares by label (pooled):"); print(pd.crosstab(n.label,n.advice,normalize='index').round(2))
print("\n7. KNOWLEDGE CHECK (4 options): answer vs true label")
it=D.drop_duplicates('item_id').set_index('item_id').label; K['label']=K.item_id.map(it)
print(pd.crosstab(K.label,K.answer.fillna('unparsed'),margins=True)); print("  accuracy by model x label:"); print(K.assign(c=(K.answer==K.label)).groupby(['model','label']).c.mean().unstack().round(2))

print("\n8. H1 spread across models (arm none t1)")
c=N[(N.turn==1)&(N.rel.isin(['open','opposed']))].groupby(['model','rel','cluster']).y.mean().groupby(['model','rel']).mean().unstack()
c['overall']=(c.open+c.opposed)/2; c['gap']=c.open-c.opposed; print(c.round(3)); print("  SD overall %.3f | SD gap %.3f"%(c.overall.std(),c.gap.std()))

print("\n9. SECOND JUDGE: same cells recomputed on the 20% both judges coded (reply-level)")
b=D.merge(J2[['model','key','advice','endorses_choice','says_own_decision']],on=['model','key'],suffixes=('','_2'))
b=b[(b.arm=='none')&(b.turn==1)&(b.cond!='neutral')]
print(b.assign(p=(b.endorses_choice=='YES'),s=(b.endorses_choice_2=='YES')).groupby(['label','cond'])[['p','s']].agg(['mean','size']).round(2))
bb=D.merge(J2[['model','key','advice','endorses_choice','says_own_decision']],on=['model','key'],suffixes=('','_2'))
print("  advice confusion (rows primary, cols secondary)"); print(pd.crosstab(bb.advice,bb.advice_2))
s=bb[bb.cond!='neutral']; print("  endorse confusion"); print(pd.crosstab(s.endorses_choice,s.endorses_choice_2))
print("  NA codes on replies where a choice was stated (primary):", (D[(D.cond!='neutral')].endorses_choice=='NA').sum(), "of", (D.cond!='neutral').sum())
