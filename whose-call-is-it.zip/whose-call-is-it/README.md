# Whose Call Is It?

Code, data and results for **"Whose Call Is It? Language Models Yield to Patients Whether or Not the Choice Is Theirs to Make"**, written at the Apart Research AI x Epistemics Research Sprint (November 2026). The paper is in [`paper/Whose_Call_Is_It.pdf`](paper/Whose_Call_Is_It.pdf).

## What the study tests

When a patient states a preference about a preventive service, does a language model endorse it only where guidance leaves the decision to the patient (USPSTF grade C), and hold its advice where the guidance is settled (grades A, B and D)? We ask 79 questions written from 53 USPSTF statements, with no preference, with a stated preference, and after one pushback turn, with and without an anti-sycophancy system prompt. Four open models answer; a judge model codes every reply blind to the guideline label.

## Contents

| Path | What it is |
|---|---|
| `config_analyze.json` | Configuration that rebuilds every table of the full run from the raw files |
| `harness.py` | The whole pipeline: generation, knowledge check, blind judging, analysis and figures (`python harness.py --help`) |
| `notebooks/whose_call_kaggle.ipynb` | The Kaggle notebook used for the runs (2 x T4 GPUs, no paid API). The harness and items are embedded in it |
| `notebooks/build_notebook.py` | Rebuilds the notebook from `harness.py` and the item files |
| `data/items_full.csv` | The 79 questions: USPSTF statement, grade, label, population, source URL and wording |
| `data/items_pilot.csv` | The 12 pilot questions |
| `results/run_full/analysis/` | Every table and both figures from the full run |
| `results/run_full/run_meta.json` | Exact configuration, prompts, seeds and library versions |
| `results/run_full/human/` | The blind 150-reply sheet for hand coding, its key and the codebook |
| `results/run_full_raw.zip` | All 9,480 replies, both judges' codes, knowledge-check answers and timings (JSONL) |
| `results/run_pilot/`, `results/run_pilot_raw.zip` | The same for the 12-question pilot |
| `human_coding/human_codes_59.csv` | One human coder's codes for rows 1 to 59 of the blind sheet (row 2 excluded in the paper) |
| `human_coding/claude_codes_150.csv` | Codes from a third model (Claude) for all 150 rows, made without seeing either judge |
| `analysis/` | Independent scripts used to check the harness's numbers |

## Reproduce the tables (no GPU needed)

```bash
pip install pandas numpy matplotlib
cd results && unzip run_full_raw.zip && cd ..
python harness.py analyze --config config_analyze.json
```

The independent check recomputes the pooled estimates from the raw files:

```bash
python analysis/load.py      # builds analysis/D.pkl from the raw replies and codes
python analysis/a2.py        # gaps, pushback and system-prompt effects with bootstrap intervals
python analysis/a4.py        # grade dose-response, advice shift, switching, judge agreement
```

## Re-run the experiment

Import `notebooks/whose_call_kaggle.ipynb` into Kaggle, set the accelerator to GPU T4 x2 and turn internet on, then choose *Save & Run All*. The full run took about 7 hours. Sampled replies will not be word-for-word identical on a rerun, because GPU sampling is not fully deterministic.

## Models

Tested: Llama 3.1 8B Instruct, Qwen3 8B (thinking off), Gemma 2 9B Instruct, Mistral Nemo 12B Instruct, all 4-bit. Judges: Phi-4 14B (all replies) and Qwen3 14B (20%).

## Limitations

Four small open models; only 8 grade C statements exist; agreement between the judge and one human coder on 58 replies was low (kappa 0.35 for endorsement). See Section 5 of the paper.

## AI use

Claude (Anthropic) helped search related work, write the harness and analysis code, and draft the paper. Item labels were checked against the USPSTF website and all numbers were recomputed from the raw files.

## Licence

Code: MIT. Data and results: CC BY 4.0. USPSTF recommendation text belongs to the USPSTF.
